const { app, BrowserWindow, Menu, dialog, ipcMain, shell } = require('electron');
const path = require('path');
const fs = require('fs');

// Modo portable: cuando el programa está empaquetado (el .exe), guarda tus datos en la carpeta
// "datos" que queda junto al .exe, para que viajen con la carpeta. Si no se puede escribir ahí
// (por ejemplo, una carpeta protegida), usa la ubicación normal de Windows.
// Debe ir antes de pedir el bloqueo de instancia única.
if (app.isPackaged) {
  try {
    const base = process.env.PORTABLE_EXECUTABLE_DIR || path.dirname(process.execPath);
    const dataDir = path.join(base, 'datos');
    fs.mkdirSync(dataDir, { recursive: true });
    fs.accessSync(dataDir, fs.constants.W_OK);
    app.setPath('userData', dataDir);
  } catch (e) {
    // sin permiso para escribir junto al .exe: se queda con la carpeta de datos normal
  }
}

const MAX_IMPORT_BYTES = 5 * 1024 * 1024;
let win = null;

// Solo una ventana a la vez: si abres el programa otra vez, se trae la que ya está abierta.
if (!app.requestSingleInstanceLock()) {
  app.quit();
}

// Si se abre un archivo .json con el programa, devuelve su ruta.
function jsonFromArgs(args) {
  for (let i = args.length - 1; i >= 1; i--) {
    const a = args[i];
    if (typeof a === 'string' && /\.json$/i.test(a) && fs.existsSync(a)) return a;
  }
  return null;
}

function sendImport(file) {
  if (!win || !file) return;
  try {
    const stat = fs.statSync(file);
    if (stat.size > MAX_IMPORT_BYTES) throw new Error('grande');
    const text = fs.readFileSync(file, 'utf8');
    win.webContents.executeJavaScript(
      'window.importFromApp && window.importFromApp(' + JSON.stringify(text) + ')'
    );
  } catch (e) {
    dialog.showErrorBox('Flete Marítimo', 'No pude leer ese archivo.');
  }
}

function createWindow() {
  Menu.setApplicationMenu(null);
  win = new BrowserWindow({
    width: 1200,
    height: 860,
    minWidth: 420,
    minHeight: 600,
    title: 'Flete Marítimo',
    icon: path.join(__dirname, 'icon.ico'),
    autoHideMenuBar: true,
    backgroundColor: '#EDF1F2',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false
    }
  });

  win.loadFile(path.join(__dirname, 'index.html'));

  // La página no abre ventanas ni se va a otros sitios.
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith('file:')) event.preventDefault();
  });

  const first = jsonFromArgs(process.argv);
  if (first) {
    win.webContents.once('did-finish-load', () => sendImport(first));
  }
  win.on('closed', () => { win = null; });
}

app.on('second-instance', (event, argv) => {
  if (win) {
    if (win.isMinimized()) win.restore();
    win.focus();
    sendImport(jsonFromArgs(argv));
  }
});

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());

// Guardar el archivo de datos con la ventana "Guardar como" de Windows.
ipcMain.handle('save-file', async (event, name, content) => {
  try {
    const fromPage = event.senderFrame && typeof event.senderFrame.url === 'string' && event.senderFrame.url.startsWith('file:');
    if (!fromPage || typeof name !== 'string' || typeof content !== 'string') {
      return { status: 'error', message: 'No se pudo guardar el archivo.' };
    }
    const safe = path.basename(name).replace(/[<>:"/\\|?*]/g, '_');
    const res = await dialog.showSaveDialog(win, {
      title: 'Guardar datos de Flete Marítimo',
      defaultPath: path.join(app.getPath('documents'), safe),
      filters: [{ name: 'Datos de Flete Marítimo', extensions: ['json'] }]
    });
    if (res.canceled || !res.filePath) return { status: 'cancel' };
    await fs.promises.writeFile(res.filePath, content, 'utf8');
    return { status: 'ok', name: path.basename(res.filePath), path: res.filePath };
  } catch (e) {
    return { status: 'error', message: 'No se pudo guardar: ' + (e && e.message ? e.message : 'error desconocido') };
  }
});
