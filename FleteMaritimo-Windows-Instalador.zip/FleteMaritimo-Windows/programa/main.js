const { app, BrowserWindow, Menu, dialog, ipcMain, shell, screen } = require('electron');
const path = require('path');
const fs = require('fs');

// Modo portable: cuando el programa está empaquetado (el .exe), guarda tus datos en la carpeta
// "datos" que queda junto al .exe, para que viajen con la carpeta. Si no se puede escribir ahí
// (por ejemplo, una carpeta protegida), usa la ubicación normal de Windows.
// Debe ir antes de pedir el bloqueo de instancia única.
if (app.isPackaged) {
  try {
    const base = process.env.PORTABLE_EXECUTABLE_DIR || path.dirname(process.execPath);
    const dataDir = path.join(base, 'datos');
    fs.mkdirSync(dataDir, { recursive: true });
    fs.accessSync(dataDir, fs.constants.W_OK);
    app.setPath('userData', dataDir);
  } catch (e) {
    // sin permiso para escribir junto al .exe: se queda con la carpeta de datos normal
  }
}

const MAX_IMPORT_BYTES = 40 * 1024 * 1024;
let win = null;

// Solo una ventana a la vez: si abres el programa otra vez, se trae la que ya está abierta.
if (!app.requestSingleInstanceLock()) {
  app.quit();
}

// Si se abre un archivo .json con el programa, devuelve su ruta.
function jsonFromArgs(args) {
  for (let i = args.length - 1; i >= 1; i--) {
    const a = args[i];
    if (typeof a === 'string' && /\.json$/i.test(a) && fs.existsSync(a)) return a;
  }
  return null;
}

function sendImport(file) {
  if (!win || !file) return;
  try {
    const stat = fs.statSync(file);
    if (stat.size > MAX_IMPORT_BYTES) throw new Error('grande');
    const text = fs.readFileSync(file, 'utf8');
    win.webContents.executeJavaScript(
      'window.importFromApp && window.importFromApp(' + JSON.stringify(text) + ')'
    );
  } catch (e) {
    dialog.showErrorBox('Flete Marítimo', 'No pude leer ese archivo.');
  }
}

// Recuerda cómo cerraste la ventana (tamaño, posición, maximizada o pantalla completa).
const stateFile = () => path.join(app.getPath('userData'), 'ventana.json');
function loadWindowState() {
  const def = { width: 1200, height: 860, maximized: false, fullscreen: false };
  try {
    const s = JSON.parse(fs.readFileSync(stateFile(), 'utf8'));
    const out = Object.assign({}, def);
    if (Number.isFinite(s.width) && Number.isFinite(s.height)) {
      out.width = Math.max(420, Math.round(s.width));
      out.height = Math.max(600, Math.round(s.height));
    }
    out.maximized = s.maximized === true;
    out.fullscreen = s.fullscreen === true;
    // Solo usa la posición si todavía cae dentro de alguna pantalla conectada.
    if (Number.isFinite(s.x) && Number.isFinite(s.y)) {
      const visible = screen.getAllDisplays().some((d) => {
        const b = d.workArea;
        return s.x + 100 > b.x && s.x + 100 < b.x + b.width && s.y >= b.y - 10 && s.y + 100 < b.y + b.height + 10;
      });
      if (visible) { out.x = Math.round(s.x); out.y = Math.round(s.y); }
    }
    return out;
  } catch (e) {
    return def;
  }
}
function saveWindowState() {
  if (!win || win.isDestroyed()) return;
  try {
    const full = win.isFullScreen();
    const max = win.isMaximized();
    const b = (full || max) ? (win.getNormalBounds ? win.getNormalBounds() : win.getBounds()) : win.getBounds();
    fs.writeFileSync(stateFile(), JSON.stringify({ x: b.x, y: b.y, width: b.width, height: b.height, maximized: max, fullscreen: full }));
  } catch (e) {
    // si no se puede guardar, no pasa nada: la próxima vez abre con el tamaño normal
  }
}

function createWindow() {
  Menu.setApplicationMenu(null);
  const ws = loadWindowState();
  win = new BrowserWindow({
    width: ws.width,
    height: ws.height,
    x: ws.x,
    y: ws.y,
    minWidth: 420,
    minHeight: 600,
    title: 'Flete Marítimo',
    icon: path.join(__dirname, 'icon.ico'),
    autoHideMenuBar: true,
    backgroundColor: '#EDF1F2',
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false
    }
  });

  win.once('ready-to-show', () => win.show());
  setTimeout(() => { if (win && !win.isDestroyed() && !win.isVisible()) win.show(); }, 3000);
  if (ws.maximized) win.maximize();
  if (ws.fullscreen) win.setFullScreen(true);
  let timer = null;
  const later = () => { clearTimeout(timer); timer = setTimeout(saveWindowState, 400); };
  ['resize', 'move', 'maximize', 'unmaximize', 'enter-full-screen', 'leave-full-screen'].forEach((ev) => win.on(ev, later));
  win.on('close', saveWindowState);
  // F11 pone y quita la pantalla completa.
  win.webContents.on('before-input-event', (event, input) => {
    if (input.type === 'keyDown' && input.key === 'F11') {
      win.setFullScreen(!win.isFullScreen());
      event.preventDefault();
    }
  });

  win.loadFile(path.join(__dirname, 'index.html'));

  // La página no abre ventanas ni se va a otros sitios.
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith('file:')) event.preventDefault();
  });

  const first = jsonFromArgs(process.argv);
  if (first) {
    win.webContents.once('did-finish-load', () => sendImport(first));
  }
  win.on('closed', () => { win = null; });
}

app.on('second-instance', (event, argv) => {
  if (win) {
    if (win.isMinimized()) win.restore();
    win.focus();
    sendImport(jsonFromArgs(argv));
  }
});

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());

// ---------- Carpeta de respaldo (por ejemplo, la de Google Drive para escritorio) ----------
const configFile = () => path.join(app.getPath('userData'), 'config.json');
function readConfig() {
  try { return JSON.parse(fs.readFileSync(configFile(), 'utf8')) || {}; } catch (e) { return {}; }
}
function writeConfig(c) {
  try { fs.writeFileSync(configFile(), JSON.stringify(c)); return true; } catch (e) { return false; }
}
function backupFolder() {
  const f = readConfig().backupFolder;
  try { if (typeof f === 'string' && fs.statSync(f).isDirectory()) return f; } catch (e) { /* no existe ahora */ }
  return null;
}
// Busca dónde suele quedar "Mi unidad" de Google Drive para abrir el selector ahí.
function driveGuess() {
  const home = app.getPath('home');
  const cands = [path.join(home, 'Google Drive'), path.join(home, 'Mi unidad'), path.join(home, 'My Drive')];
  for (let c = 'G'.charCodeAt(0); c <= 'Z'.charCodeAt(0); c++) {
    const L = String.fromCharCode(c) + ':\\';
    cands.push(L + 'Mi unidad', L + 'My Drive');
  }
  for (const c of cands) {
    try { if (fs.statSync(c).isDirectory()) return c; } catch (e) { /* sigue */ }
  }
  return app.getPath('documents');
}
const fromPage = (event) => event.senderFrame && typeof event.senderFrame.url === 'string' && event.senderFrame.url.startsWith('file:');

ipcMain.handle('backup-get', (event) => {
  if (!fromPage(event)) return { folder: null };
  const saved = readConfig().backupFolder || null;
  return { folder: saved, ok: !!backupFolder() };
});
ipcMain.handle('backup-choose', async (event) => {
  if (!fromPage(event)) return { status: 'error' };
  const res = await dialog.showOpenDialog(win, {
    title: 'Elige la carpeta de respaldo (por ejemplo, Mi unidad de Google Drive)',
    defaultPath: backupFolder() || driveGuess(),
    properties: ['openDirectory', 'createDirectory']
  });
  if (res.canceled || !res.filePaths.length) return { status: 'cancel' };
  const cfg = readConfig();
  cfg.backupFolder = res.filePaths[0];
  if (!writeConfig(cfg)) return { status: 'error' };
  return { status: 'ok', folder: cfg.backupFolder };
});
ipcMain.handle('backup-clear', (event) => {
  if (!fromPage(event)) return { status: 'error' };
  const cfg = readConfig();
  delete cfg.backupFolder;
  writeConfig(cfg);
  return { status: 'ok' };
});

// Guardar el archivo de datos: directo en la carpeta de respaldo si hay una, o con la ventana "Guardar como".
ipcMain.handle('save-file', async (event, name, content) => {
  try {
    if (!fromPage(event) || typeof name !== 'string' || typeof content !== 'string') {
      return { status: 'error', message: 'No se pudo guardar el archivo.' };
    }
    const safe = path.basename(name).replace(/[<>:"/\\|?*]/g, '_');
    const isCsv = /\.csv$/i.test(safe);
    const isHtml = /\.html?$/i.test(safe);
    const folder = isCsv || isHtml ? null : backupFolder();
    if (folder) {
      const target = path.join(folder, safe);
      await fs.promises.writeFile(target, content, 'utf8');
      return { status: 'ok', name: safe, path: target, auto: true };
    }
    const res = await dialog.showSaveDialog(win, {
      title: 'Guardar datos de Flete Marítimo',
      defaultPath: path.join(app.getPath('documents'), safe),
      filters: isCsv
        ? [{ name: 'Hoja de cálculo (Excel)', extensions: ['csv'] }]
        : isHtml
        ? [{ name: 'Página web (catálogo)', extensions: ['html'] }]
        : [{ name: 'Datos de Flete Marítimo', extensions: ['json'] }]
    });
    if (res.canceled || !res.filePath) return { status: 'cancel' };
    await fs.promises.writeFile(res.filePath, content, 'utf8');
    return { status: 'ok', name: path.basename(res.filePath), path: res.filePath };
  } catch (e) {
    return { status: 'error', message: 'No se pudo guardar: ' + (e && e.message ? e.message : 'error desconocido') };
  }
});

// Abrir un archivo de datos: la ventana empieza en la carpeta de respaldo.
ipcMain.handle('open-file', async (event) => {
  try {
    if (!fromPage(event)) return { status: 'error', message: 'No se pudo abrir el archivo.' };
    const res = await dialog.showOpenDialog(win, {
      title: 'Abrir datos de Flete Marítimo',
      defaultPath: backupFolder() || app.getPath('documents'),
      filters: [{ name: 'Datos de Flete Marítimo', extensions: ['json'] }, { name: 'Todos los archivos', extensions: ['*'] }],
      properties: ['openFile']
    });
    if (res.canceled || !res.filePaths.length) return { status: 'cancel' };
    const file = res.filePaths[0];
    if (fs.statSync(file).size > MAX_IMPORT_BYTES) return { status: 'error', message: 'Ese archivo es demasiado grande.' };
    return { status: 'ok', name: path.basename(file), text: fs.readFileSync(file, 'utf8') };
  } catch (e) {
    return { status: 'error', message: 'No pude leer ese archivo.' };
  }
});
