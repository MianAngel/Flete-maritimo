const { contextBridge, ipcRenderer } = require('electron');

// Lo único que la página puede pedirle al programa: guardar su archivo de datos.
contextBridge.exposeInMainWorld('desktop', {
  saveFile: (name, text) => ipcRenderer.invoke('save-file', String(name), String(text))
});
