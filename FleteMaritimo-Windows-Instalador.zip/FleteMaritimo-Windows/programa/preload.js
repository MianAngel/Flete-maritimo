const { contextBridge, ipcRenderer } = require('electron');

// Lo único que la página puede pedirle al programa: guardar y abrir su archivo de datos
// y elegir la carpeta de respaldo (por ejemplo, la de Google Drive).
contextBridge.exposeInMainWorld('desktop', {
  saveFile: (name, text) => ipcRenderer.invoke('save-file', String(name), String(text)),
  openFile: () => ipcRenderer.invoke('open-file'),
  getBackup: () => ipcRenderer.invoke('backup-get'),
  chooseBackup: () => ipcRenderer.invoke('backup-choose'),
  clearBackup: () => ipcRenderer.invoke('backup-clear')
});
