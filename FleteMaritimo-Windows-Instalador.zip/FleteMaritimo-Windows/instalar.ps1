# Instalador de Flete Maritimo para Windows.
# Descarga el motor oficial (Electron) desde GitHub, comprueba su huella digital y arma el programa.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

$version  = '44.5.0'
$expected = 'b3405d8847bc5054cd16272f538d22ba5b73032945e85cef26241f7135035278'
$zipName  = "electron-v$version-win32-x64.zip"
$url      = "https://github.com/electron/electron/releases/download/v$version/$zipName"

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$src  = Join-Path $here 'programa'
$dest = Join-Path $env:LOCALAPPDATA 'FleteMaritimo'
$tmp  = Join-Path $env:TEMP 'FleteMaritimo-setup'

try {
    if (-not (Test-Path (Join-Path $src 'main.js'))) {
        throw 'No encuentro la carpeta "programa". Descomprime TODO el archivo zip antes de instalar.'
    }

    Write-Host 'Cerrando el programa si esta abierto...'
    Get-Process -Name 'Flete Maritimo' -ErrorAction SilentlyContinue | Stop-Process -Force
    Start-Sleep -Milliseconds 500

    if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
    New-Item -ItemType Directory -Path $tmp | Out-Null

    # Si ya bajaste el archivo a mano y lo dejaste junto a este instalador, se usa ese.
    $zip = Join-Path $here $zipName
    if (-not (Test-Path $zip)) {
        $zip = Join-Path $tmp $zipName
        Write-Host 'Descargando el motor del programa (unos 150 MB). Puede tardar unos minutos...'
        try {
            Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
        } catch {
            throw "No pude descargar el motor. Revisa tu conexion a internet y vuelve a intentar. Si no funciona, baja a mano $url y dejalo junto a este instalador."
        }
    } else {
        Write-Host 'Usando el archivo del motor que ya estaba junto al instalador.'
    }

    Write-Host 'Verificando que la descarga sea la oficial...'
    $hash = (Get-FileHash -Path $zip -Algorithm SHA256).Hash
    if ($hash -ine $expected) {
        throw 'La descarga no coincide con la version oficial. No se instalo nada.'
    }

    Write-Host 'Preparando los archivos (puede tardar un minuto)...'
    $stage = Join-Path $tmp 'app'
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        [System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $stage)
    } catch {
        if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
        Expand-Archive -Path $zip -DestinationPath $stage -Force
    }
    Rename-Item -Path (Join-Path $stage 'electron.exe') -NewName 'Flete Maritimo.exe'
    Remove-Item (Join-Path $stage 'resources\default_app.asar') -Force -ErrorAction SilentlyContinue
    $keep = @('en-US.pak', 'es.pak', 'es-419.pak')
    Get-ChildItem -Path (Join-Path $stage 'locales') -Filter '*.pak' | Where-Object { $keep -notcontains $_.Name } | Remove-Item -Force

    $appDir = Join-Path $stage 'resources\app'
    New-Item -ItemType Directory -Path $appDir | Out-Null
    Copy-Item -Path (Join-Path $src '*') -Destination $appDir -Recurse
    Copy-Item -Path (Join-Path $src 'icon.ico') -Destination (Join-Path $stage 'icono.ico')

    Write-Host 'Instalando...'
    if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
    Copy-Item -Path $stage -Destination $dest -Recurse
    if (-not (Test-Path (Join-Path $dest 'Flete Maritimo.exe'))) {
        throw 'No se pudieron copiar los archivos.'
    }

    try {
        Write-Host 'Creando accesos directos...'
        $shell  = New-Object -ComObject WScript.Shell
        $target = Join-Path $dest 'Flete Maritimo.exe'
        $icon   = Join-Path $dest 'icono.ico'
        foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
            $lnk = $shell.CreateShortcut((Join-Path $folder 'Flete Maritimo.lnk'))
            $lnk.TargetPath       = $target
            $lnk.WorkingDirectory = $dest
            $lnk.IconLocation     = $icon
            $lnk.Save()
        }
    } catch {
        Write-Host ('Aviso: no pude crear los accesos directos. El programa quedo en: ' + (Join-Path $dest 'Flete Maritimo.exe'))
    }

    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue

    Write-Host ''
    Write-Host 'Listo. Busca "Flete Maritimo" en tu escritorio o en el menu Inicio.'
    try { Start-Process -FilePath (Join-Path $dest 'Flete Maritimo.exe') } catch { }
    exit 0
} catch {
    Write-Host ''
    Write-Host ('ERROR: ' + $_.Exception.Message)
    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
    exit 1
}
