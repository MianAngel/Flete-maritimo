@echo off
setlocal
title Desinstalar Flete Maritimo
set "DEST=%LOCALAPPDATA%\FleteMaritimo"
echo Esto quita el programa y sus accesos directos.
echo Los datos que guardaste dentro del programa NO se borran.
echo.
pause
taskkill /f /im "Flete Maritimo.exe" >nul 2>&1
if exist "%DEST%" rmdir /s /q "%DEST%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "foreach($d in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){ Remove-Item (Join-Path $d 'Flete Maritimo.lnk') -ErrorAction SilentlyContinue }"
echo.
echo Listo. Flete Maritimo fue desinstalado.
pause
