@echo off
title Instalar Flete Maritimo
echo Instalando Flete Maritimo...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
echo.
pause
